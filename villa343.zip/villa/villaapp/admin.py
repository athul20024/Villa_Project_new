from django.contrib import admin
from villaapp.models import tbl_agencyreg,tbl_userreg,tbl_villa,tbl_request,tbl_payment,tbl_order
# Register your models here.
admin.site.register(tbl_agencyreg)
admin.site.register(tbl_userreg)
admin.site.register(tbl_villa)
admin.site.register(tbl_request)
admin.site.register(tbl_payment)
admin.site.register(tbl_order)