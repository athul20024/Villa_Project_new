from django.db import models

# Create your models here.

# class tbl_login(models.Model):
#     username=models.CharField(max_length=30)
#     password=models.CharField(max_length=30)
#     class meta:
#         db_table="tbl_login"

# class tbl_category(models.Model):
#     category_name=models.CharField(max_length=30)
#     class meta:
#         db_table="tbl_category"

class tbl_order(models.Model):
    category_id=models.CharField(max_length=100)
    villa_name=models.CharField(max_length=30)
    price=models.IntegerField()
    status=models.CharField(max_length=30)
    user_id=models.CharField(max_length=100)
    class Meta:
        db_table="tbl_order"

class tbl_agencyreg(models.Model):
    firstname=models.CharField(max_length=30)
    lastname=models.CharField(max_length=30)
    place=models.CharField(max_length=30)
    email=models.CharField(max_length=30)
    phone=models.CharField(max_length=30)
    USERNAME=models.CharField(max_length=30)
    PASSWORD=models.CharField(max_length=30)
    class meta:
        db_table="tbl_agencyreg"

class tbl_userreg(models.Model):
    firstname=models.CharField(max_length=30)
    lastname=models.CharField(max_length=30)
    place=models.CharField(max_length=30)
    email=models.CharField(max_length=30)
    phone=models.CharField(max_length=30)
    USERNAME=models.CharField(max_length=30)
    PASSWORD=models.CharField(max_length=30)
    class meta:
        db_table="tbl_userreg"

        
class tbl_villa(models.Model):
    category_id=models.CharField(max_length=30)
    villa_name=models.CharField(max_length=30)
    location=models.CharField(max_length=30)
    features=models.CharField(max_length=30)
    amount=models.CharField(max_length=30)
    photo=models.ImageField()
    class meta:
        db_table="tbl_villa"

class tbl_request(models.Model):
    villa_id=models.CharField(max_length=30)
    user_id=models.CharField(max_length=30)
    amount=models.CharField(max_length=30)
    status=models.CharField(max_length=30)
    class meta:
        dbtable="tbl_request"

class tbl_payment(models.Model):
    request_id=models.CharField(max_length=30)
    user_id=models.CharField(max_length=30)
    amount=models.CharField(max_length=30)
    status=models.CharField(max_length=30)
    class meta:
        dbtable="tbl_payment"

